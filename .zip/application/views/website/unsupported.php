<div class="d-grid bg-dark">
    <div class="text-center bg-light text-dark d-grid main-div">
        <!-- <div class="text-light"> -->
        <h1 class="fs-1 text-danger">Device not supported.</h1>
    </div>
</div>
<style>
    .d-grid {
        height: 100vh;
        place-items: center;
    }


    .main-div {

        height: 50%;
        padding: 50px;
        border-radius: 30% 70% 70% 30% / 30% 30% 70% 70%;
        background-color: rebeccapurple;
    }
</style>
</body>

</html>